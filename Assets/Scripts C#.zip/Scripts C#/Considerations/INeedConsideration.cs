public interface INeedConsideration : IConsideration
{
}